const contentData = {
  alphabets: "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split(""),
  numbers: Array.from({ length: 10 }, (_, i) => i.toString()),
  months: [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ]
};

function showContent(type) {
  const container = document.getElementById("content");
  container.innerHTML = "";
  contentData[type].forEach(item => {
    const div = document.createElement("div");
    div.textContent = item;
    div.onclick = () => pronounce(item);
    container.appendChild(div);
  });
}

function pronounce(text) {
  const audio = new Audio(audio/${text}.mp3); // Path to audio file
  audio.play(); // Play the corresponding audio
}